// Termm--Fall 2022

#pragma once

class Material {
public:
  virtual ~Material();

protected:
  Material();
};
