// Termm-Fall 2022

#pragma once

#include <string>
#include "SceneNode.hpp"

SceneNode * import_lua(const std::string & filename);

